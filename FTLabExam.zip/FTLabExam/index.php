<?php

header("location: view/searchEmployee.php");
